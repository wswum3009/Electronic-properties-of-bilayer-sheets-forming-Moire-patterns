#include<stdio.h>
#include<math.h>
#include<iostream>
#include<algorithm>
#include "list.h"

#define Angles             1
#define Lattice_Constant_a sqrt(3.0)*1.42
#define RAD_DEGREE         360/(2*M_PI)
#define mat_size           Angles*Angles
using namespace std;



int main(){


 

for(float i=0.005;i<(1.047197);i+=0.001){
 cout<<i*RAD_DEGREE<<" \t "<<Lattice_Constant_a/(2.0*sin(i/2.0))<<endl; 
  
}
    
    return 0;
}