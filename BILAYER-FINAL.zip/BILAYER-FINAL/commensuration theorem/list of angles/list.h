





float quad(float x){
  return x*x;
}

int GCD(int a, int b){
    int r;
 if((a == 0) || (b == 0)){
        return 0;
      
 }else if((a < 0) || (b < 0)){
        return -1;
  }do{
        r = a % b;
        if(r == 0){
            break;
	}
        a = b;
        b = r;
    }while(true);
    return b;
}


