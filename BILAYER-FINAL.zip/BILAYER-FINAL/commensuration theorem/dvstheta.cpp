#include <iostream>
#include <math.h>

using namespace std;

#include "../LIB/Misc.h"


#define Lattice_constant_a2 1.5

float D(float a,float theta){
  return sqrt{3}*a/(2.0*sin(theta/2.0));
}

int main(){
  
for(int i=1;i<100;i++){
    cout<<(2.0*LONG_PI*i/100.0)<<"\t"<<D(1.42,2*LONG_PI*i/100)<<endl;
}
  

  
  return 0;
}