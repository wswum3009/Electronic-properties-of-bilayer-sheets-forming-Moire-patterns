#include<stdio.h>
#include<math.h>
#include<iostream>
#include<algorithm>
#include "list.h"

#define Angles             1000
#define Lattice_Constant_a 1.42
#define RAD_DEGREE         360/(2*M_PI)
using namespace std;



int main(){
    printf("# Hexagonal lattice shallcroft angles \n");
    float theta[Angles];
    float theta_output[Angles];
    
    int gamma;          //adimentional
    float delta;      //Adimentional
    int N[Angles];            //Adimentional
    int final_size=0;
    
    
    int P[Angles];
    int Q[Angles];
    float GAMMA[Angles];
    float DELTA[Angles];
    
//Inicilization of vectors;
for(int i=0;i<Angles;i++){
     theta[i]=0.0;
     theta_output[i]=0.0;
     N[i]=0;    
     Q[i]=0;
     P[i]=0;
     GAMMA[i]=0.0;
     DELTA[i]=0.0;
}

    float D=0.0;          //Armstorng

//Misc  variables
    int local_variable=0;
    int Check_list=0;
    int Save_me=0;
     
for(int q=0;q< Angles; q++){
     int p=1;

     theta[local_variable]=acos((3*quad(q)-quad(p))/(3*quad(q)+quad(p)));
     
     delta=3.0/GCD(p,3);
     gamma=GCD(3*q+p,3*q-p);

     

//checking if there is a repeated variables
     
for(int list=0;list<local_variable;list++){
  if((theta[local_variable]==theta_output[list])||(isnan(theta[local_variable]))){
    Check_list+=1;
  }
    
}
//pilas con el GCD(p,q)=1
         if((Check_list==0)&&(theta[local_variable]!=0)&&((3*(3*quad(q)+quad(p))/(delta*quad(gamma)))!=0)){
	   Q[Save_me]=q;
	   P[Save_me]=p;
	   GAMMA[Save_me]=GCD(3*q+p,3*q-p);
	   DELTA[Save_me]=3.0/(1.0*GCD(p,3));
	   theta_output[Save_me]=theta[local_variable];
	   N[Save_me]=3*(3*quad(q)+quad(p))/(delta*quad(gamma));
	   Save_me+=1;
	   final_size+=1;
	   
	 }

         local_variable+=1;
         Check_list=0;
    
  }


//filtering all the nonzero datas


 
for(int i=1;i<final_size;i++){


   cout<<theta_output[i]*RAD_DEGREE<<" \t "<<N[i]<<" \t "<<P[i]<<" \t "<<Q[i]<<" \t "<<GAMMA[i]<<" \t "<<DELTA[i]<<"\t"<<sqrt(3.0*quad(P[i])/(DELTA[i]*quad(GAMMA[i])))<<endl; 
  }

 

 

    
    return 0;
}