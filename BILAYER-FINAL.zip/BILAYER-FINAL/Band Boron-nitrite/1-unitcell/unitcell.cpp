#include<stdio.h> 
#include<math.h>
#include<iostream>
#include "../LIB/Misc.h"
#include "../LIB/Parity.h"


#include <time.h>
#include <stdlib.h>

using namespace std;
/*
OBJECTIVE:
DEFINE THE CRYSTAL STRUCTURE OF A BILAYER

*/

/*
 * 
 * This is an Open source code operating with an Open source license that comply with the Open Source Definition —. This code was initially builded to run under Ubuntu OS. This work was part of my master degree dissertation. As part of the developing and computation of bilayer graphene and bilayer nitrite boron electronic bands.

 
INPUT 
1. ANGLE AND CRISTALOGRAFIC STRUCTURE SIZE
2. OUTPUT, 
: FILE USED TO THE INPUT OF BAND STRUCTURE AND HISTOGRAM
MAX 74 ATOMS
*/



#define BICAPA                0
#define SALIDA                1
#define MOTIVO                2

#define MONOCAPA_1            0
#define MONOCAPA_2            1



#include "../LIB/lattice.h"

int main(){

    Init_motivo();
    
float angulo_entrada=0.0;
int tamano_N_motivo=4;

    cin>>angulo_entrada>>tamano_N_motivo;   //COORDENADAS REALES CENTRO!
  /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    
    
    

    float theta= angulo_entrada*DEGREE_RAD;
    
    float L_superred=Lattice_constant_a/(2.0*sin(theta/2));    
    


  /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////








int mitad_tamano_N_motivo=1*tamano_N_motivo*0.5;

int ELIGE=0;
cin>>ELIGE;



float CAPA1_[COORD][mitad_tamano_N_motivo];
float CAPA2_[COORD][mitad_tamano_N_motivo];

float COORDENADAS_ATOMICAS[COORD][tamano_N_motivo];
int   PARIDAD_ASOCIADA[COORD][mitad_tamano_N_motivo];


for(int i=0;i<mitad_tamano_N_motivo;i++){
  CAPA1_[X][i]=0.0;
  CAPA1_[Y][i]=0.0;
  
  CAPA2_[X][i]=0.0;
  CAPA2_[Y][i]=0.0;
  
  PARIDAD_ASOCIADA[MONOCAPA_1][i]=-1;
  PARIDAD_ASOCIADA[MONOCAPA_2][i]=-1;
}

for(int i=0;i<mitad_tamano_N_motivo;i++){
  COORDENADAS_ATOMICAS[X][i]=MOTIVO_ESPIRAL[X][i];
  COORDENADAS_ATOMICAS[Y][i]=MOTIVO_ESPIRAL[Y][i];
  PARIDAD_ASOCIADA[MONOCAPA_1][i]=PARIDAD___ESPIRAL[i];
}




if(tamano_N_motivo==28){
    COORDENADAS_ATOMICAS[X][8]=MOTIVO_ESPIRAL[X][14];
    COORDENADAS_ATOMICAS[Y][8]=MOTIVO_ESPIRAL[Y][14];
    PARIDAD_ASOCIADA[MONOCAPA_1][8]=PARIDAD___ESPIRAL[14];
    COORDENADAS_ATOMICAS[X][9]=MOTIVO_ESPIRAL[X][15];
    COORDENADAS_ATOMICAS[Y][9]=MOTIVO_ESPIRAL[Y][15];
    PARIDAD_ASOCIADA[MONOCAPA_1][9]=PARIDAD___ESPIRAL[15];

}

if(tamano_N_motivo==52){
    COORDENADAS_ATOMICAS[X][18]=MOTIVO_ESPIRAL[X][44];
    COORDENADAS_ATOMICAS[Y][18]=MOTIVO_ESPIRAL[Y][44];
    PARIDAD_ASOCIADA[MONOCAPA_1][18]=PARIDAD___ESPIRAL[44];
    COORDENADAS_ATOMICAS[X][19]=MOTIVO_ESPIRAL[X][45];
    COORDENADAS_ATOMICAS[Y][19]=MOTIVO_ESPIRAL[Y][45];
    PARIDAD_ASOCIADA[MONOCAPA_1][19]=PARIDAD___ESPIRAL[45];
    
    COORDENADAS_ATOMICAS[X][8]=MOTIVO_ESPIRAL[X][26];
    COORDENADAS_ATOMICAS[Y][8]=MOTIVO_ESPIRAL[Y][26];
    PARIDAD_ASOCIADA[MONOCAPA_1][8]=PARIDAD___ESPIRAL[26];
    COORDENADAS_ATOMICAS[X][9]=MOTIVO_ESPIRAL[X][27];
    COORDENADAS_ATOMICAS[Y][9]=MOTIVO_ESPIRAL[Y][27];
    PARIDAD_ASOCIADA[MONOCAPA_1][9]=PARIDAD___ESPIRAL[27];
}

if(tamano_N_motivo==76){
    COORDENADAS_ATOMICAS[X][18]=MOTIVO_ESPIRAL[X][44];
    COORDENADAS_ATOMICAS[Y][18]=MOTIVO_ESPIRAL[Y][44];
    PARIDAD_ASOCIADA[MONOCAPA_1][18]=PARIDAD___ESPIRAL[44];
    COORDENADAS_ATOMICAS[X][19]=MOTIVO_ESPIRAL[X][45];
    COORDENADAS_ATOMICAS[Y][19]=MOTIVO_ESPIRAL[Y][45];
    PARIDAD_ASOCIADA[MONOCAPA_1][19]=PARIDAD___ESPIRAL[45];
    
    COORDENADAS_ATOMICAS[X][32]=MOTIVO_ESPIRAL[X][64];
    COORDENADAS_ATOMICAS[Y][32]=MOTIVO_ESPIRAL[Y][64];
    PARIDAD_ASOCIADA[MONOCAPA_1][32]=PARIDAD___ESPIRAL[64];
    COORDENADAS_ATOMICAS[X][33]=MOTIVO_ESPIRAL[X][65];
    COORDENADAS_ATOMICAS[Y][33]=MOTIVO_ESPIRAL[Y][65];
    PARIDAD_ASOCIADA[MONOCAPA_1][33]=PARIDAD___ESPIRAL[65];
    
}

if(tamano_N_motivo==148){

  for(int i=0;i<=9;i++){
    COORDENADAS_ATOMICAS[X][44+i]=MOTIVO_ESPIRAL[X][74+i];
    COORDENADAS_ATOMICAS[Y][44+i]=MOTIVO_ESPIRAL[Y][74+i];
    PARIDAD_ASOCIADA[MONOCAPA_1][44+i]=PARIDAD___ESPIRAL[74+i];
  }
  
  for(int i=0;i<=7;i++){
    COORDENADAS_ATOMICAS[X][66+i]=MOTIVO_ESPIRAL[X][84+i];
    COORDENADAS_ATOMICAS[Y][66+i]=MOTIVO_ESPIRAL[Y][84+i];
    PARIDAD_ASOCIADA[MONOCAPA_1][66+i]=PARIDAD___ESPIRAL[84+i];
  }
}


for(int i=0;i<mitad_tamano_N_motivo;i++){
  CAPA1_[X][i]=COORDENADAS_ATOMICAS[X][i];
  CAPA1_[Y][i]=COORDENADAS_ATOMICAS[Y][i];


}

for(int i=0;i<mitad_tamano_N_motivo;i++){
  CAPA2_[X][i]=CAPA1_[X][0]-Matriz_rotacion_x(theta,CAPA1_[X][0],CAPA1_[Y][0])+Matriz_rotacion_x(theta,CAPA1_[X][i],CAPA1_[Y][i]);
  CAPA2_[Y][i]=CAPA1_[Y][0]-Matriz_rotacion_y(theta,CAPA1_[X][0],CAPA1_[Y][0])+Matriz_rotacion_y(theta,CAPA1_[X][i],CAPA1_[Y][i]);
  PARIDAD_ASOCIADA[MONOCAPA_2][i]=PARIDAD_ASOCIADA[MONOCAPA_1][i];

}


 


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////IMPRIME COORDENADAS 74DE BICAPA 0

#define TIPO_GAMMA_3      3
#define TIPO_GAMMA_4      4
#define TIPO_GAMMA_1      1

    
if(ELIGE==BICAPA){
    
  for(int i=0;i<mitad_tamano_N_motivo;i++){
      cout<<CAPA1_[X][i]<<"\t"<<CAPA1_[Y][i]<<endl;
  }      
  
  cout<<endl;
  
  for(int i=0;i<mitad_tamano_N_motivo;i++){ 
      cout<<CAPA2_[X][i]<<"\t"<<CAPA2_[Y][i]<<endl;
  }
 
}


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////// IMPRIME INDICES PARA ARMAR Matriz_rotacion_x  1

      

int REGISTRO_INTERACCION1[mitad_tamano_N_motivo];
int INDICE_ATOMICO1[2][mitad_tamano_N_motivo];

int REGISTRO_INTERACCION3[mitad_tamano_N_motivo];
int INDICE_ATOMICO3[2][mitad_tamano_N_motivo];

int REGISTRO_INTERACCION4[mitad_tamano_N_motivo];
int INDICE_ATOMICO4[2][mitad_tamano_N_motivo];

/////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////// 
//AGREGANDO INDICES NUEVOS
#define TIPO_GAMMA_12     12
#define TIPO_GAMMA_23     23
#define TIPO_GAMMA_34     34
#define TIPO_GAMMA_45     45
#define TIPO_GAMMA_56     56
#define TIPO_GAMMA_67     67
#define TIPO_GAMMA_78     78
#define TIPO_GAMMA_89     89


int REGISTRO_INTERACCION12[mitad_tamano_N_motivo];//12
int INDICE_ATOMICO12[2][mitad_tamano_N_motivo];
int REGISTRO_INTERACCION23[mitad_tamano_N_motivo];//23
int INDICE_ATOMICO23[2][mitad_tamano_N_motivo];
int REGISTRO_INTERACCION34[mitad_tamano_N_motivo];//34
int INDICE_ATOMICO34[2][mitad_tamano_N_motivo];
int REGISTRO_INTERACCION45[mitad_tamano_N_motivo];//45
int INDICE_ATOMICO45[2][mitad_tamano_N_motivo];

int REGISTRO_INTERACCION56[mitad_tamano_N_motivo];//56
int INDICE_ATOMICO56[2][mitad_tamano_N_motivo];
int REGISTRO_INTERACCION67[mitad_tamano_N_motivo];//67
int INDICE_ATOMICO67[2][mitad_tamano_N_motivo];
int REGISTRO_INTERACCION78[mitad_tamano_N_motivo];//78
int INDICE_ATOMICO78[2][mitad_tamano_N_motivo];
int REGISTRO_INTERACCION89[mitad_tamano_N_motivo];//89
int INDICE_ATOMICO89[2][mitad_tamano_N_motivo];

/////////////////////////////FIN DE AGREGADO

for(int i=0;i<mitad_tamano_N_motivo;i++){
   REGISTRO_INTERACCION1[i]=0;
   INDICE_ATOMICO1[MONOCAPA_1][i]=0;
   INDICE_ATOMICO1[MONOCAPA_2][i]=0;
   
   REGISTRO_INTERACCION3[i]=0;
   INDICE_ATOMICO3[MONOCAPA_1][i]=0;
   INDICE_ATOMICO3[MONOCAPA_2][i]=0;

   REGISTRO_INTERACCION4[i]=0;
   INDICE_ATOMICO4[MONOCAPA_1][i]=0;
   INDICE_ATOMICO4[MONOCAPA_2][i]=0;
   
//////////AGREGADO NUEVOS
   
   REGISTRO_INTERACCION12[i]=0;//12
   INDICE_ATOMICO12[MONOCAPA_1][i]=0;
   INDICE_ATOMICO12[MONOCAPA_2][i]=0;
   REGISTRO_INTERACCION23[i]=0;//23
   INDICE_ATOMICO23[MONOCAPA_1][i]=0;
   INDICE_ATOMICO23[MONOCAPA_2][i]=0;
   REGISTRO_INTERACCION34[i]=0;//34
   INDICE_ATOMICO34[MONOCAPA_1][i]=0;
   INDICE_ATOMICO34[MONOCAPA_2][i]=0;
   REGISTRO_INTERACCION45[i]=0;//45
   INDICE_ATOMICO45[MONOCAPA_1][i]=0;
   INDICE_ATOMICO45[MONOCAPA_2][i]=0;

   REGISTRO_INTERACCION56[i]=0;//56
   INDICE_ATOMICO56[MONOCAPA_1][i]=0;
   INDICE_ATOMICO56[MONOCAPA_2][i]=0;
   REGISTRO_INTERACCION67[i]=0;//67
   INDICE_ATOMICO67[MONOCAPA_1][i]=0;
   INDICE_ATOMICO67[MONOCAPA_2][i]=0;
   REGISTRO_INTERACCION78[i]=0;//78
   INDICE_ATOMICO78[MONOCAPA_1][i]=0;
   INDICE_ATOMICO78[MONOCAPA_2][i]=0;
   REGISTRO_INTERACCION89[i]=0;//89
   INDICE_ATOMICO89[MONOCAPA_1][i]=0;
   INDICE_ATOMICO89[MONOCAPA_2][i]=0;
   
//FIN AGREGADO
 }
     




for(int i=0;i<mitad_tamano_N_motivo;i++){//CAPA 1
    for(int j=0;j<mitad_tamano_N_motivo;j++){ //CAPA2
	 
	 
	 
	 ///////////////////////GAMMA 1
          if(dist_rel(0.0,0.2*Lattice_constant_a,CAPA1_[X][i],
	                                         CAPA1_[Y][i],
		                                 CAPA2_[X][j],
		                                 CAPA2_[Y][j])==1){
	    
 	    if(((PARIDAD_ASOCIADA[MONOCAPA_1][i]==ESPECIE_A)&&(PARIDAD_ASOCIADA[MONOCAPA_2][j]==ESPECIE_A))||
 	      ((PARIDAD_ASOCIADA[MONOCAPA_1][i]==ESPECIE_B)&&(PARIDAD_ASOCIADA[MONOCAPA_2][j]==ESPECIE_B))
	    	      ||
	      ((PARIDAD_ASOCIADA[MONOCAPA_1][i]==ESPECIE_A)&&(PARIDAD_ASOCIADA[MONOCAPA_2][j]==ESPECIE_B))
	      ||
	      ((PARIDAD_ASOCIADA[MONOCAPA_1][i]==ESPECIE_B)&&(PARIDAD_ASOCIADA[MONOCAPA_2][j]==ESPECIE_A))
	    ){
	    REGISTRO_INTERACCION1[i]=TIPO_GAMMA_1;
	    INDICE_ATOMICO1[MONOCAPA_1][i]=i;
	    INDICE_ATOMICO1[MONOCAPA_2][i]=j;

 		}   
	}
	  
if(REGISTRO_INTERACCION1[i]!=TIPO_GAMMA_1){
        if(dist_rel(0.8*Lattice_constant_a,1.2*Lattice_constant_a, CAPA1_[X][i],
	                                         CAPA1_[Y][i],
	                                         CAPA2_[X][j],
	                                         CAPA2_[Y][j])==1){
	    
	    if(((PARIDAD_ASOCIADA[MONOCAPA_1][i]==ESPECIE_A)&&(PARIDAD_ASOCIADA[MONOCAPA_2][j]==ESPECIE_A))||
	      ((PARIDAD_ASOCIADA[MONOCAPA_1][i]==ESPECIE_B)&&(PARIDAD_ASOCIADA[MONOCAPA_2][j]==ESPECIE_B))
	    ){
	    REGISTRO_INTERACCION3[i]=TIPO_GAMMA_3;
	    INDICE_ATOMICO3[MONOCAPA_1][i]=i;
	    INDICE_ATOMICO3[MONOCAPA_2][i]=j;
          
		}					   
	}	  
}

	
if((REGISTRO_INTERACCION1[i]!=TIPO_GAMMA_1)&&(REGISTRO_INTERACCION3[i]!=TIPO_GAMMA_3)){
        if(dist_rel(0.8*Lattice_constant_a,1.2*Lattice_constant_a, CAPA1_[X][i],
	                                         CAPA1_[Y][i],
	                                         CAPA2_[X][j],
	                                         CAPA2_[Y][j])==1){
	    //INTERACCIONES CRUZADAS
	    if(((PARIDAD_ASOCIADA[MONOCAPA_1][i]==ESPECIE_A)&&(PARIDAD_ASOCIADA[MONOCAPA_2][j]==ESPECIE_B))||
	      ((PARIDAD_ASOCIADA[MONOCAPA_1][i]==ESPECIE_B)&&(PARIDAD_ASOCIADA[MONOCAPA_2][j]==ESPECIE_A))){
	    REGISTRO_INTERACCION4[i]=TIPO_GAMMA_4;
 	    INDICE_ATOMICO4[MONOCAPA_1][i]=i;
 	    INDICE_ATOMICO4[MONOCAPA_2][i]=j;
          
		}					   
	}	
}	
  




/////////////////////////////////////////MODIFICADO DESDE AQUI


	
if(REGISTRO_INTERACCION1[i]!=TIPO_GAMMA_1){//12             .............................1
        if(dist_rel(0.1*Lattice_constant_a,0.2*Lattice_constant_a, CAPA1_[X][i],
	                                         CAPA1_[Y][i],
	                                         CAPA2_[X][j],
	                                         CAPA2_[Y][j])==1){
	    
	    if(((PARIDAD_ASOCIADA[MONOCAPA_1][i]==ESPECIE_A)&&(PARIDAD_ASOCIADA[MONOCAPA_2][j]==ESPECIE_A))||
	      ((PARIDAD_ASOCIADA[MONOCAPA_1][i]==ESPECIE_B)&&(PARIDAD_ASOCIADA[MONOCAPA_2][j]==ESPECIE_B))
	    ){
	    REGISTRO_INTERACCION12[i]=TIPO_GAMMA_12;
	    INDICE_ATOMICO12[MONOCAPA_1][i]=i;
	    INDICE_ATOMICO12[MONOCAPA_2][i]=j;
          
		}					   
	}	  
}

if(REGISTRO_INTERACCION1[i]!=TIPO_GAMMA_1){//23             .............................2
        if(dist_rel(0.2*Lattice_constant_a,0.3*Lattice_constant_a, CAPA1_[X][i],
	                                         CAPA1_[Y][i],
	                                         CAPA2_[X][j],
	                                         CAPA2_[Y][j])==1){
	    
	    if(((PARIDAD_ASOCIADA[MONOCAPA_1][i]==ESPECIE_A)&&(PARIDAD_ASOCIADA[MONOCAPA_2][j]==ESPECIE_A))||
	      ((PARIDAD_ASOCIADA[MONOCAPA_1][i]==ESPECIE_B)&&(PARIDAD_ASOCIADA[MONOCAPA_2][j]==ESPECIE_B))
	    ){
	    REGISTRO_INTERACCION23[i]=TIPO_GAMMA_23;
	    INDICE_ATOMICO23[MONOCAPA_1][i]=i;
	    INDICE_ATOMICO23[MONOCAPA_2][i]=j;
          
		}					   
	}	  
}

if(REGISTRO_INTERACCION1[i]!=TIPO_GAMMA_1){//34             .............................3
        if(dist_rel(0.3*Lattice_constant_a,0.4*Lattice_constant_a, CAPA1_[X][i],
	                                         CAPA1_[Y][i],
	                                         CAPA2_[X][j],
	                                         CAPA2_[Y][j])==1){
	    
	    if(((PARIDAD_ASOCIADA[MONOCAPA_1][i]==ESPECIE_A)&&(PARIDAD_ASOCIADA[MONOCAPA_2][j]==ESPECIE_A))||
	      ((PARIDAD_ASOCIADA[MONOCAPA_1][i]==ESPECIE_B)&&(PARIDAD_ASOCIADA[MONOCAPA_2][j]==ESPECIE_B))
	    ){
	    REGISTRO_INTERACCION34[i]=TIPO_GAMMA_34;
	    INDICE_ATOMICO34[MONOCAPA_1][i]=i;
	    INDICE_ATOMICO34[MONOCAPA_2][i]=j;
          
		}					   
	}	  
}

if(REGISTRO_INTERACCION1[i]!=TIPO_GAMMA_1){//45             .............................4
        if(dist_rel(0.4*Lattice_constant_a,0.5*Lattice_constant_a, CAPA1_[X][i],
	                                         CAPA1_[Y][i],
	                                         CAPA2_[X][j],
	                                         CAPA2_[Y][j])==1){
	    
	    if(((PARIDAD_ASOCIADA[MONOCAPA_1][i]==ESPECIE_A)&&(PARIDAD_ASOCIADA[MONOCAPA_2][j]==ESPECIE_A))||
	      ((PARIDAD_ASOCIADA[MONOCAPA_1][i]==ESPECIE_B)&&(PARIDAD_ASOCIADA[MONOCAPA_2][j]==ESPECIE_B))
	    ){
	    REGISTRO_INTERACCION45[i]=TIPO_GAMMA_45;
	    INDICE_ATOMICO45[MONOCAPA_1][i]=i;
	    INDICE_ATOMICO45[MONOCAPA_2][i]=j;
          
		}					   
	}	  
}


if(REGISTRO_INTERACCION1[i]!=TIPO_GAMMA_1){//56             .............................5
        if(dist_rel(0.5*Lattice_constant_a,0.6*Lattice_constant_a, CAPA1_[X][i],
	                                         CAPA1_[Y][i],
	                                         CAPA2_[X][j],
	                                         CAPA2_[Y][j])==1){
	    
	    if(((PARIDAD_ASOCIADA[MONOCAPA_1][i]==ESPECIE_A)&&(PARIDAD_ASOCIADA[MONOCAPA_2][j]==ESPECIE_A))||
	      ((PARIDAD_ASOCIADA[MONOCAPA_1][i]==ESPECIE_B)&&(PARIDAD_ASOCIADA[MONOCAPA_2][j]==ESPECIE_B))
	    ){
	    REGISTRO_INTERACCION56[i]=TIPO_GAMMA_56;
	    INDICE_ATOMICO56[MONOCAPA_1][i]=i;
	    INDICE_ATOMICO56[MONOCAPA_2][i]=j;
          
		}					   
	}	  
}



if(REGISTRO_INTERACCION1[i]!=TIPO_GAMMA_1){//67             .............................6
        if(dist_rel(0.6*Lattice_constant_a,0.7*Lattice_constant_a, CAPA1_[X][i],
	                                         CAPA1_[Y][i],
	                                         CAPA2_[X][j],
	                                         CAPA2_[Y][j])==1){
	    
	    if(((PARIDAD_ASOCIADA[MONOCAPA_1][i]==ESPECIE_A)&&(PARIDAD_ASOCIADA[MONOCAPA_2][j]==ESPECIE_A))||
	      ((PARIDAD_ASOCIADA[MONOCAPA_1][i]==ESPECIE_B)&&(PARIDAD_ASOCIADA[MONOCAPA_2][j]==ESPECIE_B))
	    ){
	    REGISTRO_INTERACCION67[i]=TIPO_GAMMA_67;
	    INDICE_ATOMICO67[MONOCAPA_1][i]=i;
	    INDICE_ATOMICO67[MONOCAPA_2][i]=j;
          
		}					   
	}	  
}

if(REGISTRO_INTERACCION1[i]!=TIPO_GAMMA_1){//78             .............................7
        if(dist_rel(0.7*Lattice_constant_a,0.8*Lattice_constant_a, CAPA1_[X][i],
	                                         CAPA1_[Y][i],
	                                         CAPA2_[X][j],
	                                         CAPA2_[Y][j])==1){
	    
	    if(((PARIDAD_ASOCIADA[MONOCAPA_1][i]==ESPECIE_A)&&(PARIDAD_ASOCIADA[MONOCAPA_2][j]==ESPECIE_A))||
	      ((PARIDAD_ASOCIADA[MONOCAPA_1][i]==ESPECIE_B)&&(PARIDAD_ASOCIADA[MONOCAPA_2][j]==ESPECIE_B))
	    ){
	    REGISTRO_INTERACCION78[i]=TIPO_GAMMA_78;
	    INDICE_ATOMICO78[MONOCAPA_1][i]=i;
	    INDICE_ATOMICO78[MONOCAPA_2][i]=j;
          
		}					   
	}	  
}

if(REGISTRO_INTERACCION1[i]!=TIPO_GAMMA_1){//89             .............................8
        if(dist_rel(0.8*Lattice_constant_a,0.9*Lattice_constant_a, CAPA1_[X][i],
	                                         CAPA1_[Y][i],
	                                         CAPA2_[X][j],
	                                         CAPA2_[Y][j])==1){
	    
	    if(((PARIDAD_ASOCIADA[MONOCAPA_1][i]==ESPECIE_A)&&(PARIDAD_ASOCIADA[MONOCAPA_2][j]==ESPECIE_A))||
	      ((PARIDAD_ASOCIADA[MONOCAPA_1][i]==ESPECIE_B)&&(PARIDAD_ASOCIADA[MONOCAPA_2][j]==ESPECIE_B))
	    ){
	    REGISTRO_INTERACCION89[i]=TIPO_GAMMA_89;
	    INDICE_ATOMICO89[MONOCAPA_1][i]=i;
	    INDICE_ATOMICO89[MONOCAPA_2][i]=j;
          
		}					   
	}	  
}

//AGREGADO NUEVO
	  
	
       }

     }

  
  
  
if(ELIGE==SALIDA){   
  cout<<angulo_entrada<<"\t"<<tamano_N_motivo<<endl;
  for(int i=0;i<mitad_tamano_N_motivo;i++){
     cout<<INDICE_ATOMICO1[MONOCAPA_1][i]<<"\t"<<REGISTRO_INTERACCION1[i]<<"\t"<<INDICE_ATOMICO1[MONOCAPA_2][i]<<endl;
  }
  for(int i=0;i<mitad_tamano_N_motivo;i++){
     cout<<INDICE_ATOMICO3[MONOCAPA_1][i]<<"\t"<<REGISTRO_INTERACCION3[i]<<"\t"<<INDICE_ATOMICO3[MONOCAPA_2][i]<<endl;
  }
  for(int i=0;i<mitad_tamano_N_motivo;i++){
     cout<<INDICE_ATOMICO4[MONOCAPA_1][i]<<"\t"<<REGISTRO_INTERACCION4[i]<<"\t"<<INDICE_ATOMICO4[MONOCAPA_2][i]<<endl;
  }


  for(int i=0;i<mitad_tamano_N_motivo;i++){            // .............................1 
     cout<<INDICE_ATOMICO12[MONOCAPA_1][i]<<"\t"<<REGISTRO_INTERACCION12[i]<<"\t"<<INDICE_ATOMICO12[MONOCAPA_2][i]<<endl;
  }
  for(int i=0;i<mitad_tamano_N_motivo;i++){            // .............................2
     cout<<INDICE_ATOMICO23[MONOCAPA_1][i]<<"\t"<<REGISTRO_INTERACCION23[i]<<"\t"<<INDICE_ATOMICO23[MONOCAPA_2][i]<<endl;
  }
  for(int i=0;i<mitad_tamano_N_motivo;i++){        //     .............................3
     cout<<INDICE_ATOMICO34[MONOCAPA_1][i]<<"\t"<<REGISTRO_INTERACCION34[i]<<"\t"<<INDICE_ATOMICO34[MONOCAPA_2][i]<<endl;
  }
  for(int i=0;i<mitad_tamano_N_motivo;i++){          //   .............................4
     cout<<INDICE_ATOMICO45[MONOCAPA_1][i]<<"\t"<<REGISTRO_INTERACCION45[i]<<"\t"<<INDICE_ATOMICO45[MONOCAPA_2][i]<<endl;
  }

  
  for(int i=0;i<mitad_tamano_N_motivo;i++){          //   .............................5
     cout<<INDICE_ATOMICO56[MONOCAPA_1][i]<<"\t"<<REGISTRO_INTERACCION56[i]<<"\t"<<INDICE_ATOMICO56[MONOCAPA_2][i]<<endl;
  }
  for(int i=0;i<mitad_tamano_N_motivo;i++){           //  .............................6
     cout<<INDICE_ATOMICO67[MONOCAPA_1][i]<<"\t"<<REGISTRO_INTERACCION67[i]<<"\t"<<INDICE_ATOMICO67[MONOCAPA_2][i]<<endl;
  }
  for(int i=0;i<mitad_tamano_N_motivo;i++){           //  .............................7
     cout<<INDICE_ATOMICO78[MONOCAPA_1][i]<<"\t"<<REGISTRO_INTERACCION78[i]<<"\t"<<INDICE_ATOMICO78[MONOCAPA_2][i]<<endl;
  }
  for(int i=0;i<mitad_tamano_N_motivo;i++){           //  .............................8
     cout<<INDICE_ATOMICO89[MONOCAPA_1][i]<<"\t"<<REGISTRO_INTERACCION89[i]<<"\t"<<INDICE_ATOMICO89[MONOCAPA_2][i]<<endl;
  }

}



if(ELIGE==MOTIVO){   
  for(int i=0;i<mitad_tamano_N_motivo;i++){
    if(PARIDAD_ASOCIADA[MONOCAPA_1][i]==ESPECIE_A){
      cout<<CAPA1_[X][i]<<"\t"<<CAPA1_[Y][i]<<endl;
      }
    } 
    cout<<endl;
  for(int i=0;i<mitad_tamano_N_motivo;i++){
    if(PARIDAD_ASOCIADA[MONOCAPA_1][i]==ESPECIE_B){
      cout<<CAPA1_[X][i]<<"\t"<<CAPA1_[Y][i]<<endl;
      }
    } 
    cout<<endl;
  for(int i=0;i<mitad_tamano_N_motivo;i++){
    if(PARIDAD_ASOCIADA[MONOCAPA_2][i]==ESPECIE_A){
      cout<<CAPA2_[X][i]<<"\t"<<CAPA2_[Y][i]<<endl;
      }
    } 
    cout<<endl;
  for(int i=0;i<mitad_tamano_N_motivo;i++){
    if(PARIDAD_ASOCIADA[MONOCAPA_2][i]==ESPECIE_B){
      cout<<CAPA2_[X][i]<<"\t"<<CAPA2_[Y][i]<<endl;
      }
    } 
}  



    return 0;
}
