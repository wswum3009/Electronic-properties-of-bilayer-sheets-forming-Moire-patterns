.././Band.out <A_inp.dat> A_bandas.dat
.././Band.out <B_inp.dat> B_bandas.dat
.././Band.out <C_inp.dat> C_bandas.dat
.././Band.out <D_inp.dat> D_bandas.dat
.././Band.out <E_inp.dat> E_bandas.dat
