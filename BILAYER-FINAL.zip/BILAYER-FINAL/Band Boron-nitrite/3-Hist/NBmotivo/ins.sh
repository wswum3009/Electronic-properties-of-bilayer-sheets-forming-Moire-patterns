.././DOSLOCAL.out <A_inp.dat> A_dos.dat
.././DOSLOCAL.out <B_inp.dat> B_dos.dat
.././DOSLOCAL.out <C_inp.dat> C_dos.dat
.././DOSLOCAL.out <D_inp.dat> D_dos.dat
.././DOSLOCAL.out <E_inp.dat> E_dos.dat
