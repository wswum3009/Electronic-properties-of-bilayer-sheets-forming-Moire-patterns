#define A          0
#define B          1
#define AB         2
#define X          0
#define Y          1
#define Z          2
#define L          0
#define R          1
#define C          2
#define COORD      2

#define  Gamma_0     2.33  //ev In plane hopping parameter
#define  Gamma_1     0.32  //ev  A1 - A2 hopping parameter
#define  Gamma_2     0.4  //ev  B1 - B2 Hopping parameter
#define  Gamma_3     0.25  //0.3ev     A1 - A2 or B1 - B2 far hopping parameter
#define  Gamma_4     0.0  //ev  A1 - B2 B1 - A2 hopping paramter

#define  DEGREE_RAD  2*M_PI/360                  // Grados a radianes
#define  Lattice_constant_a   1.45             //constante de red Grafeno 1.42 A
#define  b_lattice            2*M_PI/Lattice_constant_a
#define  hbar       1 //6.582119514e-16 //hbar [eV s]         
//Entre Castro neto y tesis twisted hay una diferencia de valor vf, creale a castro, por que ese valor depnde de la seleccion de a!
// #define  vf          3*Gamma_0*Lattice_constant_a/(2*hbar)  //m/s fermi velocity //Es la velocidad dada en A/s o m/s
#define  Armstrong   10e-10
/////////////////////Queda la posibilidad de usar 6.582119514e4?

float x_long_pi=0.0;
float LONG_PI=2*atan(1/x_long_pi);

float quad(float x){
  return x*x;
}


float dist(float x,float y){
  return sqrt(quad(x)+quad(y));
}


float fvabs(float x){
  return sqrt(x*x);
}

int dist_rel(float tol_min,float tol_max,float x1,float y1,float x2,float y2){
  if((dist(x2-x1,y2-y1)<=tol_max)&&(dist(x2-x1,y2-y1)>=tol_min)){// ESTA DENTRO DE RANGO DE ACCION
    return 1;
  }
  if((dist(x2-x1,y2-y1)>tol_max)||(dist(x2-x1,y2-y1)<tol_min)){// FUERA DE RANGO DE ACCION
    return 0;
  } 
}

float Matriz_rotacion_x(float theta,float x,float y){
   return x*cos(theta)-y*sin(theta);
     
}

float Matriz_rotacion_y(float theta,float x,float y){
   return x*sin(theta)+y*cos(theta);
        
}

int Inter_layer(int Capa,int Numero){
  
  int cont=0;
  
if(Capa==0){cont=0;}
if(Capa==1){cont=2;}
  
if((Numero%2)==0){
    if(Numero==0){return 0+cont;}
    if(Numero!=0){
      return 2*Numero+cont;
    }
}
    if((Numero%2)!=0){
      return 2*Numero-1+cont;}
    
}
