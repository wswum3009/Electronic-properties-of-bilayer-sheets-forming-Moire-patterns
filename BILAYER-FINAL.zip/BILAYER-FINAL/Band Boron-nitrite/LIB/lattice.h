#define ESPECIE_A             0
#define ESPECIE_B             1


float MOTIVO_ESPIRAL[COORD][96];
int   PARIDAD___ESPIRAL[96];


void Init_motivo(){
  
for(int i=0;i<96;i++){
  MOTIVO_ESPIRAL[X][i]=0.0;
  MOTIVO_ESPIRAL[Y][i]=0.0;
  PARIDAD___ESPIRAL[i]=0;
}

  MOTIVO_ESPIRAL[X][0]=0;
  MOTIVO_ESPIRAL[Y][0]=0;
  PARIDAD___ESPIRAL[0]=ESPECIE_A;
  MOTIVO_ESPIRAL[X][1]=Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][1]=0;
  PARIDAD___ESPIRAL[1]=ESPECIE_B;

  MOTIVO_ESPIRAL[X][2]=(3.0/2.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][2]=-(sqrt(3.0)/2.0)*Lattice_constant_a;
  PARIDAD___ESPIRAL[2]=ESPECIE_A;
  MOTIVO_ESPIRAL[X][3]=(5.0/2.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][3]=-(sqrt(3.0)/2.0)*Lattice_constant_a;
  PARIDAD___ESPIRAL[3]=ESPECIE_B;
  
  MOTIVO_ESPIRAL[X][4]=(1.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][4]=-(sqrt(3.0))*Lattice_constant_a;
  PARIDAD___ESPIRAL[4]=ESPECIE_B;
  MOTIVO_ESPIRAL[X][5]=(0.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][5]=-(sqrt(3.0))*Lattice_constant_a;
  PARIDAD___ESPIRAL[5]=ESPECIE_A;
  
  MOTIVO_ESPIRAL[X][6]=(-1.0/2.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][6]=-(sqrt(3.0)/2.0)*Lattice_constant_a;
  PARIDAD___ESPIRAL[6]=ESPECIE_B;
  MOTIVO_ESPIRAL[X][7]=(-3.0/2.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][7]=-(sqrt(3.0)/2.0)*Lattice_constant_a;
  PARIDAD___ESPIRAL[7]=ESPECIE_A;
  
  MOTIVO_ESPIRAL[X][8]=(-2.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][8]=(0.0)*Lattice_constant_a;
  PARIDAD___ESPIRAL[8]=ESPECIE_B;
  MOTIVO_ESPIRAL[X][9]=(-3.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][9]=(0.0)*Lattice_constant_a;
  PARIDAD___ESPIRAL[9]=ESPECIE_A;
  
  MOTIVO_ESPIRAL[X][10]=(-3.0/2.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][10]=(sqrt(3.0)/2.0)*Lattice_constant_a;
  PARIDAD___ESPIRAL[10]=ESPECIE_A;
  MOTIVO_ESPIRAL[X][11]=(-1.0/2.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][11]=(sqrt(3.0)/2.0)*Lattice_constant_a;
  PARIDAD___ESPIRAL[11]=ESPECIE_B;
  
  MOTIVO_ESPIRAL[X][12]=(0.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][12]=(sqrt(3.0))*Lattice_constant_a;
  PARIDAD___ESPIRAL[12]=ESPECIE_A;
  MOTIVO_ESPIRAL[X][13]=(1.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][13]=(sqrt(3.0))*Lattice_constant_a;
  PARIDAD___ESPIRAL[13]=ESPECIE_B;
  
  
  MOTIVO_ESPIRAL[X][14]=(3.0/2.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][14]=(sqrt(3.0)/2.0)*Lattice_constant_a;
  PARIDAD___ESPIRAL[14]=ESPECIE_A;
  MOTIVO_ESPIRAL[X][15]=(5.0/2.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][15]=(sqrt(3.0)/2.0)*Lattice_constant_a;
  PARIDAD___ESPIRAL[15]=ESPECIE_B;
  
  
  MOTIVO_ESPIRAL[X][16]=(3.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][16]=(0.0)*Lattice_constant_a;
  PARIDAD___ESPIRAL[16]=ESPECIE_A;
  MOTIVO_ESPIRAL[X][17]=(4.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][17]=(0.0)*Lattice_constant_a;
  PARIDAD___ESPIRAL[17]=ESPECIE_B;
  
  
  MOTIVO_ESPIRAL[X][18]=(9.0/2.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][18]=(-sqrt(3.0)/2.0)*Lattice_constant_a;
  PARIDAD___ESPIRAL[18]=ESPECIE_A;
  MOTIVO_ESPIRAL[X][19]=(11.0/2.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][19]=(-sqrt(3.0)/2.0)*Lattice_constant_a;
  PARIDAD___ESPIRAL[19]=ESPECIE_B;
  
  
  MOTIVO_ESPIRAL[X][20]=(4.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][20]=(-sqrt(3.0))*Lattice_constant_a;
  PARIDAD___ESPIRAL[20]=ESPECIE_B;
  MOTIVO_ESPIRAL[X][21]=(3.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][21]=(-sqrt(3.0))*Lattice_constant_a;
  PARIDAD___ESPIRAL[21]=ESPECIE_A;
  
  
  MOTIVO_ESPIRAL[X][22]=(5.0/2.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][22]=(-3.0*sqrt(3.0)/2.0)*Lattice_constant_a;
  PARIDAD___ESPIRAL[22]=ESPECIE_B;
  MOTIVO_ESPIRAL[X][23]=(3.0/2.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][23]=(-3.0*sqrt(3.0)/2.0)*Lattice_constant_a;
  PARIDAD___ESPIRAL[23]=ESPECIE_A;
  
  MOTIVO_ESPIRAL[X][24]=(1.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][24]=(-2.0*sqrt(3.0))*Lattice_constant_a;
  PARIDAD___ESPIRAL[24]=ESPECIE_B;
  MOTIVO_ESPIRAL[X][25]=(0.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][25]=(-2.0*sqrt(3.0))*Lattice_constant_a;
  PARIDAD___ESPIRAL[25]=ESPECIE_A;
  
  MOTIVO_ESPIRAL[X][26]=(-1.0/2.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][26]=(-3.0*sqrt(3.0)/2.0)*Lattice_constant_a;
  PARIDAD___ESPIRAL[26]=ESPECIE_B;
  MOTIVO_ESPIRAL[X][27]=(-3.0/2.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][27]=(-3.0*sqrt(3.0)/2.0)*Lattice_constant_a;
  PARIDAD___ESPIRAL[27]=ESPECIE_A;
  
  MOTIVO_ESPIRAL[X][28]=(-2.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][28]=(-sqrt(3.0))*Lattice_constant_a;
  PARIDAD___ESPIRAL[28]=ESPECIE_B;
  MOTIVO_ESPIRAL[X][29]=(-3.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][29]=(-sqrt(3.0))*Lattice_constant_a;
  PARIDAD___ESPIRAL[29]=ESPECIE_A;
  
  MOTIVO_ESPIRAL[X][30]=(-7.0/2.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][30]=(-sqrt(3.0)/2.0)*Lattice_constant_a;
  PARIDAD___ESPIRAL[30]=ESPECIE_B;
  MOTIVO_ESPIRAL[X][31]=(-9.0/2.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][31]=(-sqrt(3.0)/2.0)*Lattice_constant_a;
  PARIDAD___ESPIRAL[31]=ESPECIE_A;
  
  
  
  MOTIVO_ESPIRAL[X][32]=(-5.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][32]=(0.0)*Lattice_constant_a;
  PARIDAD___ESPIRAL[32]=ESPECIE_B;
  MOTIVO_ESPIRAL[X][33]=(-6.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][33]=(0.0)*Lattice_constant_a;
  PARIDAD___ESPIRAL[33]=ESPECIE_A;

  MOTIVO_ESPIRAL[X][34]=(-9.0/2.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][34]=(sqrt(3.0)/2.0)*Lattice_constant_a;
  PARIDAD___ESPIRAL[34]=ESPECIE_A;
  MOTIVO_ESPIRAL[X][35]=(-7.0/2.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][35]=(sqrt(3.0)/2.0)*Lattice_constant_a;
  PARIDAD___ESPIRAL[35]=ESPECIE_B;

  MOTIVO_ESPIRAL[X][36]=(-3.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][36]=(sqrt(3.0))*Lattice_constant_a;
  PARIDAD___ESPIRAL[36]=ESPECIE_A;
  MOTIVO_ESPIRAL[X][37]=(-2.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][37]=(sqrt(3.0))*Lattice_constant_a;
  PARIDAD___ESPIRAL[37]=ESPECIE_B;
  
  MOTIVO_ESPIRAL[X][38]=(-3.0/2.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][38]=(3.0*sqrt(3.0)/2.0)*Lattice_constant_a;
  PARIDAD___ESPIRAL[38]=ESPECIE_A;
  MOTIVO_ESPIRAL[X][39]=(-1.0/2.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][39]=(3.0*sqrt(3.0)/2.0)*Lattice_constant_a;
  PARIDAD___ESPIRAL[39]=ESPECIE_B;
  
  MOTIVO_ESPIRAL[X][40]=(0.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][40]=(2.0*sqrt(3.0))*Lattice_constant_a;
  PARIDAD___ESPIRAL[40]=ESPECIE_A;
  MOTIVO_ESPIRAL[X][41]=(1.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][41]=(2.0*sqrt(3.0))*Lattice_constant_a;
  PARIDAD___ESPIRAL[41]=ESPECIE_B;
  
  MOTIVO_ESPIRAL[X][42]=(3.0/2.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][42]=(3.0*sqrt(3.0)/2.0)*Lattice_constant_a;
  PARIDAD___ESPIRAL[42]=ESPECIE_A;
  MOTIVO_ESPIRAL[X][43]=(5.0/2.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][43]=(3.0*sqrt(3.0)/2.0)*Lattice_constant_a;
  PARIDAD___ESPIRAL[43]=ESPECIE_B;
  
  
  MOTIVO_ESPIRAL[X][44]=(3.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][44]=(sqrt(3.0))*Lattice_constant_a;
  PARIDAD___ESPIRAL[44]=ESPECIE_A;
  MOTIVO_ESPIRAL[X][45]=(4.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][45]=(sqrt(3.0))*Lattice_constant_a;
  PARIDAD___ESPIRAL[45]=ESPECIE_B;
  
  MOTIVO_ESPIRAL[X][46]=(9.0/2.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][46]=(sqrt(3.0)/2.0)*Lattice_constant_a;
  PARIDAD___ESPIRAL[46]=ESPECIE_A;
  MOTIVO_ESPIRAL[X][47]=(11.0/2.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][47]=(sqrt(3.0)/2.0)*Lattice_constant_a;
  PARIDAD___ESPIRAL[47]=ESPECIE_B;
  
  MOTIVO_ESPIRAL[X][48]=(6.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][48]=(0.0)*Lattice_constant_a;
  PARIDAD___ESPIRAL[48]=ESPECIE_A;
  MOTIVO_ESPIRAL[X][49]=(7.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][49]=(0.0)*Lattice_constant_a;
  PARIDAD___ESPIRAL[49]=ESPECIE_B;
  
  MOTIVO_ESPIRAL[X][50]=(15.0/2.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][50]=(-sqrt(3.0)/2.0)*Lattice_constant_a;
  PARIDAD___ESPIRAL[50]=ESPECIE_A;
  MOTIVO_ESPIRAL[X][51]=(17.0/2.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][51]=(-sqrt(3.0)/2.0)*Lattice_constant_a;
  PARIDAD___ESPIRAL[51]=ESPECIE_B;
  
  MOTIVO_ESPIRAL[X][52]=(7.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][52]=(-sqrt(3.0))*Lattice_constant_a;
  PARIDAD___ESPIRAL[52]=ESPECIE_B;
  MOTIVO_ESPIRAL[X][53]=(6.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][53]=(-sqrt(3.0))*Lattice_constant_a;
  PARIDAD___ESPIRAL[53]=ESPECIE_A;
     
  
  MOTIVO_ESPIRAL[X][54]=(11.0/2.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][54]=(-3.0*sqrt(3.0)/2.0)*Lattice_constant_a;
  PARIDAD___ESPIRAL[54]=ESPECIE_B;
  MOTIVO_ESPIRAL[X][55]=(9.0/2.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][55]=(-3.0*sqrt(3.0)/2.0)*Lattice_constant_a;
  PARIDAD___ESPIRAL[55]=ESPECIE_A;
  
  MOTIVO_ESPIRAL[X][56]=(4.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][56]=(-2.0*sqrt(3.0))*Lattice_constant_a;
  PARIDAD___ESPIRAL[56]=ESPECIE_B;
  MOTIVO_ESPIRAL[X][57]=(3.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][57]=(-2.0*sqrt(3.0))*Lattice_constant_a;
  PARIDAD___ESPIRAL[57]=ESPECIE_A;

  MOTIVO_ESPIRAL[X][58]=(5.0/2.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][58]=(-5.0*sqrt(3.0)/2.0)*Lattice_constant_a;
  PARIDAD___ESPIRAL[58]=ESPECIE_B;
  MOTIVO_ESPIRAL[X][59]=(3.0/2.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][59]=(-5.0*sqrt(3.0)/2.0)*Lattice_constant_a;
  PARIDAD___ESPIRAL[59]=ESPECIE_A;

  MOTIVO_ESPIRAL[X][60]=(1.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][60]=(-3.0*sqrt(3.0))*Lattice_constant_a;
  PARIDAD___ESPIRAL[60]=ESPECIE_B;
  MOTIVO_ESPIRAL[X][61]=(0.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][61]=(-3.0*sqrt(3.0))*Lattice_constant_a;
  PARIDAD___ESPIRAL[61]=ESPECIE_A;

  MOTIVO_ESPIRAL[X][62]=(-1.0/2.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][62]=(-5.0*sqrt(3.0)/2.0)*Lattice_constant_a;
  PARIDAD___ESPIRAL[62]=ESPECIE_B;
  MOTIVO_ESPIRAL[X][63]=(-3.0/2.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][63]=(-5.0*sqrt(3.0)/2.0)*Lattice_constant_a;
  PARIDAD___ESPIRAL[63]=ESPECIE_A;
  
  MOTIVO_ESPIRAL[X][64]=(-2.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][64]=(-2.0*sqrt(3.0))*Lattice_constant_a;
  PARIDAD___ESPIRAL[64]=ESPECIE_B;
  MOTIVO_ESPIRAL[X][65]=(-3.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][65]=(-2.0*sqrt(3.0))*Lattice_constant_a;
  PARIDAD___ESPIRAL[65]=ESPECIE_A;
  
  MOTIVO_ESPIRAL[X][66]=(-7.0/2.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][66]=(-3.0*sqrt(3.0)/2.0)*Lattice_constant_a;
  PARIDAD___ESPIRAL[66]=ESPECIE_B;
  MOTIVO_ESPIRAL[X][67]=(-9.0/2.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][67]=(-3.0*sqrt(3.0)/2.0)*Lattice_constant_a;
  PARIDAD___ESPIRAL[67]=ESPECIE_A;
  
  
  
  MOTIVO_ESPIRAL[X][68]=(-5.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][68]=(-sqrt(3.0))*Lattice_constant_a;
  PARIDAD___ESPIRAL[68]=ESPECIE_B;
  MOTIVO_ESPIRAL[X][69]=(-6.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][69]=(-sqrt(3.0))*Lattice_constant_a;
  PARIDAD___ESPIRAL[69]=ESPECIE_A;
  
  MOTIVO_ESPIRAL[X][70]=(-13.0/2.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][70]=(-sqrt(3.0)/2.0)*Lattice_constant_a;
  PARIDAD___ESPIRAL[70]=ESPECIE_B;
  MOTIVO_ESPIRAL[X][71]=(-15.0/2.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][71]=(-sqrt(3.0)/2.0)*Lattice_constant_a;
  PARIDAD___ESPIRAL[71]=ESPECIE_A;
  
  MOTIVO_ESPIRAL[X][72]=(-13.0/2.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][72]=(sqrt(3.0)/2.0)*Lattice_constant_a;
  PARIDAD___ESPIRAL[72]=ESPECIE_B;
  MOTIVO_ESPIRAL[X][73]=(-15.0/2.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][73]=(sqrt(3.0)/2.0)*Lattice_constant_a;
  PARIDAD___ESPIRAL[73]=ESPECIE_A;
  
  
  
/**********************************************************************************/

  MOTIVO_ESPIRAL[X][74]=(3.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][74]=(2.0*sqrt(3.0))*Lattice_constant_a;
  PARIDAD___ESPIRAL[74]=ESPECIE_A;
  MOTIVO_ESPIRAL[X][75]=(4.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][75]=(2.0*sqrt(3.0))*Lattice_constant_a;
  PARIDAD___ESPIRAL[75]=ESPECIE_B;  
  

  MOTIVO_ESPIRAL[X][76]=(5.0/2.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][76]=(sqrt(3.0)*5.0/2.0)*Lattice_constant_a;
  PARIDAD___ESPIRAL[76]=ESPECIE_B;
  MOTIVO_ESPIRAL[X][77]=(3.0/2.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][77]=(sqrt(3.0)*5.0/2.0)*Lattice_constant_a;
  PARIDAD___ESPIRAL[77]=ESPECIE_A;
  

  MOTIVO_ESPIRAL[X][78]=(-1.0/2.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][78]=(sqrt(3.0)*5.0/2.0)*Lattice_constant_a;
  PARIDAD___ESPIRAL[78]=ESPECIE_B;
  MOTIVO_ESPIRAL[X][79]=(-3.0/2.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][79]=(sqrt(3.0)*5.0/2.0)*Lattice_constant_a;
  PARIDAD___ESPIRAL[79]=ESPECIE_A;  
  

  MOTIVO_ESPIRAL[X][80]=(-2.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][80]=(sqrt(3.0)*2.0)*Lattice_constant_a;
  PARIDAD___ESPIRAL[80]=ESPECIE_B;
  MOTIVO_ESPIRAL[X][81]=(-3.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][81]=(sqrt(3.0)*2.0)*Lattice_constant_a;
  PARIDAD___ESPIRAL[81]=ESPECIE_A;
  
  MOTIVO_ESPIRAL[X][82]=(-7.0/2.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][82]=(3.0*sqrt(3.0)/2.0)*Lattice_constant_a;
  PARIDAD___ESPIRAL[82]=ESPECIE_B;
  MOTIVO_ESPIRAL[X][83]=(-9.0/2.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][83]=(3.0*sqrt(3.0)/2.0)*Lattice_constant_a;
  PARIDAD___ESPIRAL[83]=ESPECIE_A;
  
  MOTIVO_ESPIRAL[X][84]=(11.0/2.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][84]=(-5.0*sqrt(3.0)/2.0)*Lattice_constant_a;
  PARIDAD___ESPIRAL[84]=ESPECIE_B;
  MOTIVO_ESPIRAL[X][85]=(9.0/2.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][85]=(-5.0*sqrt(3.0)/2.0)*Lattice_constant_a;
  PARIDAD___ESPIRAL[85]=ESPECIE_A;
  
  
  
  MOTIVO_ESPIRAL[X][86]=(4.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][86]=(-3.0*sqrt(3.0))*Lattice_constant_a;
  PARIDAD___ESPIRAL[86]=ESPECIE_B;
  MOTIVO_ESPIRAL[X][87]=(3.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][87]=(-3.0*sqrt(3.0))*Lattice_constant_a;
  PARIDAD___ESPIRAL[87]=ESPECIE_A;
  
  
  MOTIVO_ESPIRAL[X][88]=(5.0/2.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][88]=(-7.0*sqrt(3.0)/2.0)*Lattice_constant_a;
  PARIDAD___ESPIRAL[88]=ESPECIE_B;
  MOTIVO_ESPIRAL[X][89]=(3.0/2.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][89]=(-7.0*sqrt(3.0)/2.0)*Lattice_constant_a;
  PARIDAD___ESPIRAL[89]=ESPECIE_A;
  
  
  MOTIVO_ESPIRAL[X][90]=(-1.0/2.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][90]=(-7.0*sqrt(3.0)/2.0)*Lattice_constant_a;
  PARIDAD___ESPIRAL[90]=ESPECIE_B;
  MOTIVO_ESPIRAL[X][91]=(-3.0/2.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][91]=(-7.0*sqrt(3.0)/2.0)*Lattice_constant_a;
  PARIDAD___ESPIRAL[91]=ESPECIE_A;
  
  MOTIVO_ESPIRAL[X][92]=(-2.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][92]=(-3.0*sqrt(3.0))*Lattice_constant_a;
  PARIDAD___ESPIRAL[92]=ESPECIE_B;
  MOTIVO_ESPIRAL[X][93]=(-3.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][93]=(-sqrt(3.0)*3.0)*Lattice_constant_a;
  PARIDAD___ESPIRAL[93]=ESPECIE_A;
  
  
  MOTIVO_ESPIRAL[X][94]=(-7.0/2.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][94]=(-5.0*sqrt(3.0)/2.0)*Lattice_constant_a;
  PARIDAD___ESPIRAL[94]=ESPECIE_B;
  MOTIVO_ESPIRAL[X][95]=(-9.0/2.0)*Lattice_constant_a;
  MOTIVO_ESPIRAL[Y][95]=(-5.0*sqrt(3.0)/2.0)*Lattice_constant_a;
  PARIDAD___ESPIRAL[95]=ESPECIE_A;
  
  

  
  
    

  
  
}






float SUPER_RECIPROCO[COORD][72];


void Init_motivo_rec(float super_L){
  
for(int i=0;i<72;i++){
  SUPER_RECIPROCO[X][i]=0.0;
  SUPER_RECIPROCO[Y][i]=0.0;
}

  SUPER_RECIPROCO[X][0]=(2.0*LONG_PI/(3.0*super_L))*(-1.0);
  SUPER_RECIPROCO[Y][0]=(2.0*LONG_PI/(3.0*super_L))*(-1.0/sqrt(3.0));
  SUPER_RECIPROCO[X][1]=(2.0*LONG_PI/(3.0*super_L))*(0.0);
  SUPER_RECIPROCO[Y][1]=(2.0*LONG_PI/(3.0*super_L))*(-2.0/sqrt(3.0));
  SUPER_RECIPROCO[X][2]=(2.0*LONG_PI/(3.0*super_L))*(1.0);
  SUPER_RECIPROCO[Y][2]=(2.0*LONG_PI/(3.0*super_L))*(-1.0/sqrt(3.0));
  SUPER_RECIPROCO[X][3]=(2.0*LONG_PI/(3.0*super_L))*(2.0);
  SUPER_RECIPROCO[Y][3]=(2.0*LONG_PI/(3.0*super_L))*(-2.0/sqrt(3.0));
  SUPER_RECIPROCO[X][4]=(2.0*LONG_PI/(3.0*super_L))*(3.0);
  SUPER_RECIPROCO[Y][4]=(2.0*LONG_PI/(3.0*super_L))*(-1.0/sqrt(3.0));
  SUPER_RECIPROCO[X][5]=(2.0*LONG_PI/(3.0*super_L))*(4.0);
  SUPER_RECIPROCO[Y][5]=(2.0*LONG_PI/(3.0*super_L))*(-2.0/sqrt(3.0));
  SUPER_RECIPROCO[X][6]=(2.0*LONG_PI/(3.0*super_L))*(5.0);
  SUPER_RECIPROCO[Y][6]=(2.0*LONG_PI/(3.0*super_L))*(-1.0/sqrt(3.0));
  SUPER_RECIPROCO[X][7]=(2.0*LONG_PI/(3.0*super_L))*(6.0);
  SUPER_RECIPROCO[Y][7]=(2.0*LONG_PI/(3.0*super_L))*(-2.0/sqrt(3.0));
  SUPER_RECIPROCO[X][8]=(2.0*LONG_PI/(3.0*super_L))*(7.0);
  SUPER_RECIPROCO[Y][8]=(2.0*LONG_PI/(3.0*super_L))*(-1.0/sqrt(3.0));
  SUPER_RECIPROCO[X][9]=(2.0*LONG_PI/(3.0*super_L))*(8.0);
  SUPER_RECIPROCO[Y][9]=(2.0*LONG_PI/(3.0*super_L))*(-2.0/sqrt(3.0));
  SUPER_RECIPROCO[X][10]=(2.0*LONG_PI/(3.0*super_L))*(9.0);
  SUPER_RECIPROCO[Y][10]=(2.0*LONG_PI/(3.0*super_L))*(-1.0/sqrt(3.0));
  SUPER_RECIPROCO[X][11]=(2.0*LONG_PI/(3.0*super_L))*(10.0);
  SUPER_RECIPROCO[Y][11]=(2.0*LONG_PI/(3.0*super_L))*(-2.0/sqrt(3.0));

  SUPER_RECIPROCO[X][12]=(2.0*LONG_PI/(3.0*super_L))*(-1.0);
  SUPER_RECIPROCO[Y][12]=(2.0*LONG_PI/(3.0*super_L))*(1.0/sqrt(3.0));
  SUPER_RECIPROCO[X][13]=(2.0*LONG_PI/(3.0*super_L))*(0.0);
  SUPER_RECIPROCO[Y][13]=(2.0*LONG_PI/(3.0*super_L))*(2.0/sqrt(3.0));
  SUPER_RECIPROCO[X][14]=(2.0*LONG_PI/(3.0*super_L))*(1.0);
  SUPER_RECIPROCO[Y][14]=(2.0*LONG_PI/(3.0*super_L))*(1.0/sqrt(3.0));
  SUPER_RECIPROCO[X][15]=(2.0*LONG_PI/(3.0*super_L))*(2.0);
  SUPER_RECIPROCO[Y][15]=(2.0*LONG_PI/(3.0*super_L))*(2.0/sqrt(3.0));
  SUPER_RECIPROCO[X][16]=(2.0*LONG_PI/(3.0*super_L))*(3.0);
  SUPER_RECIPROCO[Y][16]=(2.0*LONG_PI/(3.0*super_L))*(1.0/sqrt(3.0));
  SUPER_RECIPROCO[X][17]=(2.0*LONG_PI/(3.0*super_L))*(4.0);
  SUPER_RECIPROCO[Y][17]=(2.0*LONG_PI/(3.0*super_L))*(2.0/sqrt(3.0));
  SUPER_RECIPROCO[X][18]=(2.0*LONG_PI/(3.0*super_L))*(5.0);
  SUPER_RECIPROCO[Y][18]=(2.0*LONG_PI/(3.0*super_L))*(1.0/sqrt(3.0));
  SUPER_RECIPROCO[X][19]=(2.0*LONG_PI/(3.0*super_L))*(6.0);
  SUPER_RECIPROCO[Y][19]=(2.0*LONG_PI/(3.0*super_L))*(2.0/sqrt(3.0));
  SUPER_RECIPROCO[X][20]=(2.0*LONG_PI/(3.0*super_L))*(7.0);
  SUPER_RECIPROCO[Y][20]=(2.0*LONG_PI/(3.0*super_L))*(1.0/sqrt(3.0));
  SUPER_RECIPROCO[X][21]=(2.0*LONG_PI/(3.0*super_L))*(8.0);
  SUPER_RECIPROCO[Y][21]=(2.0*LONG_PI/(3.0*super_L))*(2.0/sqrt(3.0));
  SUPER_RECIPROCO[X][22]=(2.0*LONG_PI/(3.0*super_L))*(9.0);
  SUPER_RECIPROCO[Y][22]=(2.0*LONG_PI/(3.0*super_L))*(1.0/sqrt(3.0));
  SUPER_RECIPROCO[X][23]=(2.0*LONG_PI/(3.0*super_L))*(10.0);
  SUPER_RECIPROCO[Y][23]=(2.0*LONG_PI/(3.0*super_L))*(2.0/sqrt(3.0));
  
  SUPER_RECIPROCO[X][24]=(2.0*LONG_PI/(3.0*super_L))*(-1.0);
  SUPER_RECIPROCO[Y][24]=(2.0*LONG_PI/(3.0*super_L))*(5.0/sqrt(3.0));
  SUPER_RECIPROCO[X][25]=(2.0*LONG_PI/(3.0*super_L))*(0.0);
  SUPER_RECIPROCO[Y][25]=(2.0*LONG_PI/(3.0*super_L))*(4.0/sqrt(3.0));
  SUPER_RECIPROCO[X][26]=(2.0*LONG_PI/(3.0*super_L))*(1.0);
  SUPER_RECIPROCO[Y][26]=(2.0*LONG_PI/(3.0*super_L))*(5.0/sqrt(3.0));
  SUPER_RECIPROCO[X][27]=(2.0*LONG_PI/(3.0*super_L))*(2.0);
  SUPER_RECIPROCO[Y][27]=(2.0*LONG_PI/(3.0*super_L))*(4.0/sqrt(3.0));
  SUPER_RECIPROCO[X][28]=(2.0*LONG_PI/(3.0*super_L))*(3.0);
  SUPER_RECIPROCO[Y][28]=(2.0*LONG_PI/(3.0*super_L))*(5.0/sqrt(3.0));
  SUPER_RECIPROCO[X][29]=(2.0*LONG_PI/(3.0*super_L))*(4.0);
  SUPER_RECIPROCO[Y][29]=(2.0*LONG_PI/(3.0*super_L))*(4.0/sqrt(3.0));
  SUPER_RECIPROCO[X][30]=(2.0*LONG_PI/(3.0*super_L))*(5.0);
  SUPER_RECIPROCO[Y][30]=(2.0*LONG_PI/(3.0*super_L))*(5.0/sqrt(3.0));
  SUPER_RECIPROCO[X][31]=(2.0*LONG_PI/(3.0*super_L))*(6.0);
  SUPER_RECIPROCO[Y][31]=(2.0*LONG_PI/(3.0*super_L))*(4.0/sqrt(3.0));
  SUPER_RECIPROCO[X][32]=(2.0*LONG_PI/(3.0*super_L))*(7.0);
  SUPER_RECIPROCO[Y][32]=(2.0*LONG_PI/(3.0*super_L))*(5.0/sqrt(3.0));
  SUPER_RECIPROCO[X][33]=(2.0*LONG_PI/(3.0*super_L))*(8.0);
  SUPER_RECIPROCO[Y][33]=(2.0*LONG_PI/(3.0*super_L))*(4.0/sqrt(3.0));
  SUPER_RECIPROCO[X][34]=(2.0*LONG_PI/(3.0*super_L))*(9.0);
  SUPER_RECIPROCO[Y][34]=(2.0*LONG_PI/(3.0*super_L))*(5.0/sqrt(3.0));
  SUPER_RECIPROCO[X][35]=(2.0*LONG_PI/(3.0*super_L))*(10.0);
  SUPER_RECIPROCO[Y][35]=(2.0*LONG_PI/(3.0*super_L))*(4.0/sqrt(3.0));
  
  SUPER_RECIPROCO[X][36]=(2.0*LONG_PI/(3.0*super_L))*(-1.0);
  SUPER_RECIPROCO[Y][36]=(2.0*LONG_PI/(3.0*super_L))*(7.0/sqrt(3.0));
  SUPER_RECIPROCO[X][37]=(2.0*LONG_PI/(3.0*super_L))*(0.0);
  SUPER_RECIPROCO[Y][37]=(2.0*LONG_PI/(3.0*super_L))*(8.0/sqrt(3.0));
  SUPER_RECIPROCO[X][38]=(2.0*LONG_PI/(3.0*super_L))*(1.0);
  SUPER_RECIPROCO[Y][38]=(2.0*LONG_PI/(3.0*super_L))*(7.0/sqrt(3.0));
  SUPER_RECIPROCO[X][39]=(2.0*LONG_PI/(3.0*super_L))*(2.0);
  SUPER_RECIPROCO[Y][39]=(2.0*LONG_PI/(3.0*super_L))*(8.0/sqrt(3.0));
  SUPER_RECIPROCO[X][40]=(2.0*LONG_PI/(3.0*super_L))*(3.0);
  SUPER_RECIPROCO[Y][40]=(2.0*LONG_PI/(3.0*super_L))*(7.0/sqrt(3.0));
  SUPER_RECIPROCO[X][41]=(2.0*LONG_PI/(3.0*super_L))*(4.0);
  SUPER_RECIPROCO[Y][41]=(2.0*LONG_PI/(3.0*super_L))*(8.0/sqrt(3.0));
  SUPER_RECIPROCO[X][42]=(2.0*LONG_PI/(3.0*super_L))*(5.0);
  SUPER_RECIPROCO[Y][42]=(2.0*LONG_PI/(3.0*super_L))*(7.0/sqrt(3.0));
  SUPER_RECIPROCO[X][43]=(2.0*LONG_PI/(3.0*super_L))*(6.0);
  SUPER_RECIPROCO[Y][43]=(2.0*LONG_PI/(3.0*super_L))*(8.0/sqrt(3.0));
  SUPER_RECIPROCO[X][44]=(2.0*LONG_PI/(3.0*super_L))*(7.0);
  SUPER_RECIPROCO[Y][44]=(2.0*LONG_PI/(3.0*super_L))*(7.0/sqrt(3.0));
  SUPER_RECIPROCO[X][45]=(2.0*LONG_PI/(3.0*super_L))*(8.0);
  SUPER_RECIPROCO[Y][45]=(2.0*LONG_PI/(3.0*super_L))*(8.0/sqrt(3.0));
  SUPER_RECIPROCO[X][46]=(2.0*LONG_PI/(3.0*super_L))*(9.0);
  SUPER_RECIPROCO[Y][46]=(2.0*LONG_PI/(3.0*super_L))*(7.0/sqrt(3.0));
  SUPER_RECIPROCO[X][47]=(2.0*LONG_PI/(3.0*super_L))*(10.0);
  SUPER_RECIPROCO[Y][47]=(2.0*LONG_PI/(3.0*super_L))*(8.0/sqrt(3.0));
 
  SUPER_RECIPROCO[X][48]=(2.0*LONG_PI/(3.0*super_L))*(-1.0);
  SUPER_RECIPROCO[Y][48]=(2.0*LONG_PI/(3.0*super_L))*(11.0/sqrt(3.0));
  SUPER_RECIPROCO[X][49]=(2.0*LONG_PI/(3.0*super_L))*(0.0);
  SUPER_RECIPROCO[Y][49]=(2.0*LONG_PI/(3.0*super_L))*(10.0/sqrt(3.0));
  SUPER_RECIPROCO[X][50]=(2.0*LONG_PI/(3.0*super_L))*(1.0);
  SUPER_RECIPROCO[Y][50]=(2.0*LONG_PI/(3.0*super_L))*(11.0/sqrt(3.0));
  SUPER_RECIPROCO[X][51]=(2.0*LONG_PI/(3.0*super_L))*(2.0);
  SUPER_RECIPROCO[Y][51]=(2.0*LONG_PI/(3.0*super_L))*(10.0/sqrt(3.0));
  SUPER_RECIPROCO[X][52]=(2.0*LONG_PI/(3.0*super_L))*(3.0);
  SUPER_RECIPROCO[Y][52]=(2.0*LONG_PI/(3.0*super_L))*(11.0/sqrt(3.0));
  SUPER_RECIPROCO[X][53]=(2.0*LONG_PI/(3.0*super_L))*(4.0);
  SUPER_RECIPROCO[Y][53]=(2.0*LONG_PI/(3.0*super_L))*(10.0/sqrt(3.0));
  SUPER_RECIPROCO[X][54]=(2.0*LONG_PI/(3.0*super_L))*(5.0);
  SUPER_RECIPROCO[Y][54]=(2.0*LONG_PI/(3.0*super_L))*(11.0/sqrt(3.0));
  SUPER_RECIPROCO[X][55]=(2.0*LONG_PI/(3.0*super_L))*(6.0);
  SUPER_RECIPROCO[Y][55]=(2.0*LONG_PI/(3.0*super_L))*(10.0/sqrt(3.0));
  SUPER_RECIPROCO[X][56]=(2.0*LONG_PI/(3.0*super_L))*(7.0);
  SUPER_RECIPROCO[Y][56]=(2.0*LONG_PI/(3.0*super_L))*(11.0/sqrt(3.0));
  SUPER_RECIPROCO[X][57]=(2.0*LONG_PI/(3.0*super_L))*(8.0);
  SUPER_RECIPROCO[Y][57]=(2.0*LONG_PI/(3.0*super_L))*(10.0/sqrt(3.0));
  SUPER_RECIPROCO[X][58]=(2.0*LONG_PI/(3.0*super_L))*(9.0);
  SUPER_RECIPROCO[Y][58]=(2.0*LONG_PI/(3.0*super_L))*(11.0/sqrt(3.0));
  SUPER_RECIPROCO[X][59]=(2.0*LONG_PI/(3.0*super_L))*(10.0);
  SUPER_RECIPROCO[Y][59]=(2.0*LONG_PI/(3.0*super_L))*(10.0/sqrt(3.0));

  SUPER_RECIPROCO[X][60]=(2.0*LONG_PI/(3.0*super_L))*(-1.0);
  SUPER_RECIPROCO[Y][60]=(2.0*LONG_PI/(3.0*super_L))*(13.0/sqrt(3.0));
  SUPER_RECIPROCO[X][61]=(2.0*LONG_PI/(3.0*super_L))*(0.0);
  SUPER_RECIPROCO[Y][61]=(2.0*LONG_PI/(3.0*super_L))*(14.0/sqrt(3.0));
  SUPER_RECIPROCO[X][62]=(2.0*LONG_PI/(3.0*super_L))*(1.0);
  SUPER_RECIPROCO[Y][62]=(2.0*LONG_PI/(3.0*super_L))*(13.0/sqrt(3.0));
  SUPER_RECIPROCO[X][63]=(2.0*LONG_PI/(3.0*super_L))*(2.0);
  SUPER_RECIPROCO[Y][63]=(2.0*LONG_PI/(3.0*super_L))*(14.0/sqrt(3.0));
  SUPER_RECIPROCO[X][64]=(2.0*LONG_PI/(3.0*super_L))*(3.0);
  SUPER_RECIPROCO[Y][64]=(2.0*LONG_PI/(3.0*super_L))*(13.0/sqrt(3.0));
  SUPER_RECIPROCO[X][65]=(2.0*LONG_PI/(3.0*super_L))*(4.0);
  SUPER_RECIPROCO[Y][65]=(2.0*LONG_PI/(3.0*super_L))*(14.0/sqrt(3.0));
  SUPER_RECIPROCO[X][66]=(2.0*LONG_PI/(3.0*super_L))*(5.0);
  SUPER_RECIPROCO[Y][66]=(2.0*LONG_PI/(3.0*super_L))*(13.0/sqrt(3.0));
  SUPER_RECIPROCO[X][67]=(2.0*LONG_PI/(3.0*super_L))*(6.0);
  SUPER_RECIPROCO[Y][67]=(2.0*LONG_PI/(3.0*super_L))*(14.0/sqrt(3.0));
  SUPER_RECIPROCO[X][68]=(2.0*LONG_PI/(3.0*super_L))*(7.0);
  SUPER_RECIPROCO[Y][68]=(2.0*LONG_PI/(3.0*super_L))*(13.0/sqrt(3.0));
  SUPER_RECIPROCO[X][69]=(2.0*LONG_PI/(3.0*super_L))*(8.0);
  SUPER_RECIPROCO[Y][69]=(2.0*LONG_PI/(3.0*super_L))*(14.0/sqrt(3.0));
  SUPER_RECIPROCO[X][70]=(2.0*LONG_PI/(3.0*super_L))*(9.0);
  SUPER_RECIPROCO[Y][70]=(2.0*LONG_PI/(3.0*super_L))*(13.0/sqrt(3.0));
  SUPER_RECIPROCO[X][71]=(2.0*LONG_PI/(3.0*super_L))*(10.0);
  SUPER_RECIPROCO[Y][71]=(2.0*LONG_PI/(3.0*super_L))*(14.0/sqrt(3.0));
}






















