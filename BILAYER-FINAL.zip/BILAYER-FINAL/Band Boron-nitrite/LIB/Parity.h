#define PAR      1
#define IMPAR    0

int paridad(int argumento){
    if((argumento%2)==0){
      return PAR;//PAR
    }else if((argumento%2)!=0){
    return IMPAR; //Impar
    }
}
      
      
float maximo(float x,float y){
  if(x>=y){return x;}
  if(y>=x){return y;}
}


float minimo(float x,float y){
  if(x>=y){return y;}
  if(y>=x){return x;}
}


