 
./../Band.out <A_inp.dat> A_banda.dat
./../Band.out <B_inp.dat> B_banda.dat
./../Band.out <C_inp.dat> C_banda.dat
./../Band.out <D_inp.dat> D_banda.dat
./../Band.out <E_inp.dat> E_banda.dat

