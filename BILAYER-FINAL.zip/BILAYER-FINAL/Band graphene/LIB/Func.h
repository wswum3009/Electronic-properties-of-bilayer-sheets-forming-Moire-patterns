#include <cfloat>
#include <cmath>

void Ceroi(int **Mat,int size_N){
  for(int i=0;i<size_N;i++){
    for(int j=0;j<size_N;j++){
      Mat[i][j]=0.0;
    }
  }
}

void Cerof(float **Mat,int size_N){
  for(int i=0;i<size_N;i++){
    for(int j=0;j<size_N;j++){
      Mat[i][j]=0.0;
    }
  }
}


void Showmati(int **Mat,int size_N){
   for(int i=0;i<size_N;i++){
     for(int j=0;j<size_N;j++){
        cout<<Mat[i][j]<<" ";
	}
	cout<<endl;
   }
}




float Perturbacion(float kx_0,float ky_0,float kx,float ky){
  return sqrt((kx-kx_0)*(kx-kx_0)+(ky-ky_0)*(ky-ky_0));
}

float binomio(float x,float y){
  return x*x+y*y;
}

float VanderWaals(float kx_0,float ky_0,float kx,float ky,float a,float b,float gamma_cte){
  float comp=gamma_cte*sqrt(2*exp(a*b)*(
  (2/pow(binomio(a,dist(kx-kx_0,ky-ky_0)),3))+
  (1/pow(binomio(2*a,dist(kx-kx_0,ky-ky_0)),3))-
  ((4*(2*pow(a,2)+pow(dist(kx-kx_0,ky-ky_0),2))*(4*pow(a,4)+pow(a,2)*pow(dist(kx-kx_0,ky-ky_0),2)+pow(dist(kx-kx_0,ky-ky_0),4)))
  /( pow(binomio(a,dist(kx-kx_0,ky-ky_0)),3)*pow(binomio(2*a,dist(kx-kx_0,ky-ky_0)),3) ) ) 
   
  ));
  
  
if(isnan(comp)==0){
  
  return (gamma_cte/LONG_PI)*sqrt(exp(a*b)*(
  (4/pow(binomio(a,dist(kx-kx_0,ky-ky_0)),3))+
  (1/pow(binomio(2*a,dist(kx-kx_0,ky-ky_0)),3))-
  ((4*(2*pow(a,2)+pow(dist(kx-kx_0,ky-ky_0),2))*(4*pow(a,4)+pow(a,2)*pow(dist(kx-kx_0,ky-ky_0),2)+pow(dist(kx-kx_0,ky-ky_0),4)))
  /( pow(binomio(a,dist(kx-kx_0,ky-ky_0)),3)*pow(binomio(2*a,dist(kx-kx_0,ky-ky_0)),3) ) ) 
   
  ));
}

if(isnan(comp)==1){
  return 0;
}
  
}




float VanderWaals_inv(float kx_0,float ky_0,float kx,float ky,float a,float b,float gamma_cte){
  return -gamma_cte*( exp(-2*a*(dist(kx-kx_0,ky-ky_0)-b))-2.0*exp(-a*(dist(kx-kx_0,ky-ky_0)-b)) );
  
}


float funcion_f(float kx,float ky){//Castro Neto
    return sqrt(3.0+2.0*cos(Lattice_constant_a*ky*sqrt(3.0))+4.0*cos(sqrt(3.0)*Lattice_constant_a*ky/2.0)*cos(3.0*Lattice_constant_a*kx/2.0));
}

float funcion_f_superred(float lcte,float kx,float ky){//Castro Neto
    return sqrt(3.0+2.0*cos(lcte*ky*sqrt(3.0))+4.0*cos(sqrt(3.0)*lcte*ky/2.0)*cos(3.0*lcte*kx/2.0));
}



int GCD(int a, int b){
    int r;
 if((a == 0) || (b == 0)){
        return 0;
      
 }else if((a < 0) || (b < 0)){
        return -1;
  }do{
        r = a % b;
        if(r == 0){
            break;
	}
        a = b;
        b = r;
    }while(true);
    return b;
}



void PAS(int N, float x,float y0,float yf){//Puntos Alta Simetria
  float linea=.0;
  for(int i=0;i<N;i++){
    linea=y0+(i/(yf-y0))*yf;
     cout<<x<<"\t"<<linea<<endl;
  }
}

